import ctypes
import os

# Path to Rust-compiled library
lib_path = os.path.join(
    os.path.dirname(__file__),
    "..",
    "emulator-core",
    "target",
    "debug",
    "libemulator_core.so"   # Linux
    # "emulator_core.dll"   # Windows
    # "libemulator_core.dylib"  # Mac
)

lib = ctypes.cdll.LoadLibrary(lib_path)

# Define function signatures
lib.init_system.restype = None
lib.load_game.argtypes = [ctypes.c_char_p]
lib.run_frame.restype = None
