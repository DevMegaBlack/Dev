from emulator_api import lib
import time

print("Initializing emulator...")
lib.init_system()

rom = input("Enter ROM path: ")

lib.load_game(rom.encode("utf-8"))

print("Running emulator... press CTRL+C to quit")

try:
    while True:
        lib.run_frame()
        time.sleep(1/60)  # pretend 60FPS loop
except KeyboardInterrupt:
    print("Exited.")
