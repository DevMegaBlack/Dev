pub struct Audio;

impl Audio {
    pub fn new() -> Self {
        Audio
    }

    pub fn process(&self) {
        // TODO: audio DSP emulation
    }
}
