pub struct Memory {
    pub ram: Vec<u8>,
}

impl Memory {
    pub fn new(size: usize) -> Self {
        Memory {
            ram: vec![0; size],
        }
    }

    pub fn read8(&self, addr: usize) -> u8 {
        self.ram[addr]
    }

    pub fn write8(&mut self, addr: usize, value: u8) {
        self.ram[addr] = value;
    }
}
