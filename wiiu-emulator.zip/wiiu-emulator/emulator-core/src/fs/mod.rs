pub fn load_rom(path: &str) -> Vec<u8> {
    std::fs::read(path).expect("Failed to read ROM")
}
