use crate::cpu::Cpu;
use crate::memory::Memory;
use crate::gpu::Gpu;
use crate::audio::Audio;
use crate::input::InputState;

pub struct System {
    pub cpu: Cpu,
    pub memory: Memory,
    pub gpu: Gpu,
    pub audio: Audio,
    pub input: InputState,
}

impl System {
    pub fn new() -> Self {
        System {
            cpu: Cpu::new(),
            memory: Memory::new(1024 * 1024 * 256), // 256MB RAM
            gpu: Gpu::new(),
            audio: Audio::new(),
            input: InputState::new(),
        }
    }

    pub fn run_frame(&mut self) {
        self.cpu.step();
        self.gpu.render_frame();
        self.audio.process();
    }
}
