mod cpu;
mod memory;
mod gpu;
mod audio;
mod input;
mod fs;
pub mod system;

use std::ffi::{CStr};
use std::os::raw::c_char;
use std::sync::Mutex;

static mut SYSTEM: Option<Mutex<system::System>> = None;

#[no_mangle]
pub extern "C" fn init_system() {
    unsafe {
        SYSTEM = Some(Mutex::new(system::System::new()));
    }
}

#[no_mangle]
pub extern "C" fn load_game(path: *const c_char) {
    let c_str = unsafe { CStr::from_ptr(path) };
    let path_str = c_str.to_str().unwrap();

    let rom = fs::load_rom(path_str);
    println!("Loaded ROM: {} bytes", rom.len());
}

#[no_mangle]
pub extern "C" fn run_frame() {
    unsafe {
        if let Some(system) = SYSTEM.as_mut() {  // use `as_mut()` instead of `&SYSTEM`
            let mut sys = system.lock().unwrap();
            sys.run_frame();
        }
    }
}
