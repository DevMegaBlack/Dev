pub struct Cpu {
    pub registers: [u64; 32],
}

impl Cpu {
    pub fn new() -> Self {
        Cpu {
            registers: [0; 32],
        }
    }

    pub fn step(&mut self) {
        // TODO: decode + execute instructions
    }
}
