pub struct InputState {
    pub buttons: u32,
}

impl InputState {
    pub fn new() -> Self {
        InputState { buttons: 0 }
    }
}
