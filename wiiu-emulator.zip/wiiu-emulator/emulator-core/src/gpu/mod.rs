pub struct Gpu;

impl Gpu {
    pub fn new() -> Self {
        Gpu
    }

    pub fn render_frame(&self) {
        // TODO: GPU emulation here
    }
}
