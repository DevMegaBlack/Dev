import os
import platform
import subprocess

# Detect platform
current_platform = platform.system()
crate_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "emulator-core"))

if current_platform == "Windows":
    target_name = "emulator_core.dll"
elif current_platform == "Linux":
    target_name = "libemulator_core.so"
elif current_platform == "Darwin":
    target_name = "libemulator_core.dylib"
else:
    raise Exception(f"Unsupported platform: {current_platform}")

print(f"Building Rust emulator for {current_platform}...")

# Run cargo build
subprocess.run(["cargo", "build"], cwd=crate_path, check=True)

# Path to the compiled library
if current_platform == "Windows":
    lib_path = os.path.join(crate_path, "target", "debug", "emulator_core.dll")
else:
    lib_path = os.path.join(crate_path, "target", "debug", target_name)

print(f"Build complete! Library located at: {lib_path}")
